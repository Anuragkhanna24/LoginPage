import React, { useState, useEffect } from 'react';
import { Button, Offcanvas } from 'react-bootstrap';

const Sidebar = ({ name, ...props }) => {
  const [show, setShow] = useState(window.innerWidth > 780);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    const handleResize = () => {
      setShow(window.innerWidth > 580);
    };

    // Add event listener to handle window resize
    window.addEventListener('resize', handleResize);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []); // Empty dependency array ensures the effect runs only once on component mount

  return (
    <>
      <Button variant="white" onClick={handleShow} className="me-2 fs-6">
        &#9776;
      </Button>
      
      <Offcanvas show={show} onHide={handleClose} {...props} className="sidebar-div">
        <Offcanvas.Header closeButton ={window.innerWidth <= 780}>
          <Offcanvas.Title>SIDEBAR</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body >
          <div>DASHBOARD</div>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
};

export default Sidebar;
