import React from 'react'
import { Navbar, Nav } from 'react-bootstrap';
import { MdLogout } from "react-icons/md";
import './header.css'
import Sidebar from './sidebar';


const Header = () => {
  return (
    <>
    <div className="navbar">
        <img src='./logo192.png ' className='' style={{width:"50px"}}></img>

        <div className='d-flex'>
        <div className='nav-items d-flex'>
      <i className=""><MdLogout/></i>
      <a href="#"> home</a>
      </div>
      <div className='nav-items d-flex'>
      <i className=""><MdLogout/></i>
      <a href="#"> Search</a>
      </div>
      <div className='nav-items d-flex'>
      <i className=""><MdLogout/></i>
      <a href="#"> about</a>
      </div>
      <div className='nav-items d-flex'>
      <i className=""><MdLogout/></i>
      <a href="#"> logout</a>
      </div>
     
        </div>
     
     
    </div>
    <Sidebar/>
    </>

  );
};

export default Header
